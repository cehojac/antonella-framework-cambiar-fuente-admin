<?php

namespace CFA\Admin;

class PageAdmin extends Admin
{
    public static function index()
    {

    }

}
