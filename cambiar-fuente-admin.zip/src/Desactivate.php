<?php
namespace CFA;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
