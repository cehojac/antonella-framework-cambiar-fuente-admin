<?php
namespace CFA;

class Init
{
    public function __construct()
    {

    }

    public static function index()
    {

    }
}
